# pip install waitress
from waitress import serve

# under cmsimde import fossilapp
import wsgi

# run cmsimde dynamic site with production waitress
serve(wsgi.app, host='0.0.0.0', port=5005, url_scheme='https')