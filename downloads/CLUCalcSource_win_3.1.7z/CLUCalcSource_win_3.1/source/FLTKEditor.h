/// LICENSE START
////////////////////////////////////////////////////////////////////////////////////
//
// This file is part of the CLUCalc program.
// CLUCalc is an interactive Clifford calculator with OpenGL visualiations.
//
// 
// Copyright (C) 2002-2004  Christian B.U. Perwass
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
// The GNU Library General Public License can be found in the file
// license.txt distributed with this library.
//
// Please send all queries and comments to
//
// email: help@clucalc.info
// mail: Institut fuer Informatik, Olshausenstr. 40, 24098 Kiel, Germany.
//
////////////////////////////////////////////////////////////////////////////////////
/// LICENSE END

#if !defined( _FLTKEDITOR_H__INCLUDED_ )
#define _FLTKEDITOR_H__INCLUDED_

#include <FL/Fl.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Double_Window.H>
#include <FL/fl_ask.H>
#include <FL/Fl_File_Chooser.H>
#include <FL/Fl_Menu_Bar.H>
#include <FL/Fl_Input.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Return_Button.H>
#include <FL/Fl_Text_Buffer.H>
#include <FL/Fl_Text_Editor.H>

#include <string>
#include <vector>

using namespace std;



class CFLTKEditor : public Fl_Double_Window
{
public:
	CFLTKEditor();
	CFLTKEditor(int iPosX, int iPosY, int iWidth, int iHeight, const char* pcFilename = 0);
	~CFLTKEditor(void);

	virtual bool Create(int iPosX, int iPosY, int iWidth, int iHeight, const char* pcFilename = 0);
	void Show();

	// Helper Functions
	void LoadFile(const char* pcFilename, int iPos = -1);
	void SaveFile(const char* pcFilename);

protected:
	bool CheckSave();
	bool SetTitle();
	void SetNameAndPath();

protected:
	// Virtual Functions that influence Editor behaviour

	// Override this function to create your own menus
	virtual void InitMenu();

	// Override this function to add your own styles
	virtual void InitStyleTable();

protected:
	// Virtual Functions called by Callbacks
	virtual void Copy();
	virtual void Cut();
	virtual void Delete();
	virtual void Paste();

	virtual void Find();
	virtual void Find2();

	virtual void Replace();
	virtual void Replace2();
	virtual void ReplaceAll();
	virtual void ReplaceCan();

	virtual void New();
	virtual void Load();
	virtual void Insert();
	virtual void Close();
	virtual void Save();
	virtual void SaveAs();

	virtual void Quit();

	virtual void Changed(int iVal, int nInserted, int nDeleted, 
						int iVal2, const char* pcVal);

	virtual void StyleUnfinished(int iVal);
	virtual void StyleUpdate(int iPos, int nInserted,	int nDeleted,
							 int nRestyled, const char *pcDeletedText);

	virtual void StyleParse(const char *pcText, char *pcStyle, int iLength);

protected:
	// Callbacks
	static void CB_Copy(Fl_Widget* pWidget, void *pData);
	static void CB_Cut(Fl_Widget* pWidget, void *pData);
	static void CB_Delete(Fl_Widget* pWidget, void *pData);
	static void CB_Paste(Fl_Widget* pWidget, void *pData);

	static void CB_Find(Fl_Widget* pWidget, void *pData);
	static void CB_Find2(Fl_Widget* pWidget, void *pData);

	static void CB_Replace(Fl_Widget* pWidget, void *pData);
	static void CB_Replace2(Fl_Widget* pWidget, void *pData);
	static void CB_ReplaceAll(Fl_Widget* pWidget, void *pData);
	static void CB_ReplaceCan(Fl_Widget* pWidget, void *pData);

	static void CB_New(Fl_Widget* pWidget, void *pData);
	static void CB_Load(Fl_Widget* pWidget, void *pData);
	static void CB_Insert(Fl_Widget* pWidget, void *pData);
	static void CB_Close(Fl_Widget* pWidget, void *pData);
	static void CB_Save(Fl_Widget* pWidget, void *pData);
	static void CB_SaveAs(Fl_Widget* pWidget, void *pData);

	static void CB_Quit(Fl_Widget* pWidget, void *pData);

	static void CB_Changed(int iVal, int nInserted, int nDeleted, 
						int iVal2, const char* pcVal, void* pvVal);

	static void CB_StyleUnfinished(int iVal, void *pvVal);
	static void CB_StyleUpdate(int iPos, int nInserted,	int nDeleted,
								int nRestyled, const char *deletedText,
								void *pvData);

protected:
	Fl_Window          *m_pReplaceDlg;
	Fl_Input           *m_pReplaceFind;
	Fl_Input           *m_pReplaceWith;
	Fl_Button          *m_pReplaceAll;
	Fl_Return_Button   *m_pReplaceNext;
	Fl_Button          *m_pReplaceCancel;

	Fl_Text_Editor     *m_pEditor;
	char				m_pcSearchString[256];

	bool               m_bChanged;
	bool			   m_bLoading;
	bool				m_bIsOK;
	bool				m_bReparsing;
	bool				m_bReparseAll;

	string             m_sFilename;
	string			   m_sName;
	string			   m_sPath;
	string             m_sTitle;
	Fl_Text_Buffer     *m_pTextBuf;
	
	Fl_Text_Buffer     *m_pStyleBuf;
	vector<Fl_Text_Display::Style_Table_Entry> m_vecStyleTable;

	Fl_Menu_Bar			*m_pMenuBar;
	vector<Fl_Menu_Item> m_vecMenuItem;

	string m_sFileChooserLoadTitle;
	string m_sFileChooserSaveTitle;
	string m_sFileChooserPattern;
};


#endif  // #define _FLTKEDITOR_H__INCLUDED_

