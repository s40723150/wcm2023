/// LICENSE START
////////////////////////////////////////////////////////////////////////////////////
//
// This file is part of the CLUCalc program.
// CLUCalc is an interactive Clifford calculator with OpenGL visualiations.
//
// 
// Copyright (C) 2002-2004  Christian B.U. Perwass
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
// The GNU Library General Public License can be found in the file
// license.txt distributed with this library.
//
// Please send all queries and comments to
//
// email: help@clucalc.info
// mail: Institut fuer Informatik, Olshausenstr. 40, 24098 Kiel, Germany.
//
////////////////////////////////////////////////////////////////////////////////////
/// LICENSE END



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#include "FLTKOutput.h"


CFLTKOutput::CFLTKOutput() : Fl_Double_Window(100, 100)
{
	m_bIsOK = false;
	m_bHasMenu = false;

	m_pWinOutput = 0;
	m_pTextBuf = 0;
}


CFLTKOutput::CFLTKOutput(int iPosX, int iPosY, int iWidth, int iHeight, const char* pcTitle)
		: Fl_Double_Window(iWidth, iHeight)
{
	m_bIsOK = false;
	m_bHasMenu = false;

	m_pWinOutput = 0;
	m_pTextBuf = 0;

	Create(iPosX, iPosY, iWidth, iHeight, pcTitle);
	Show();
}



CFLTKOutput::~CFLTKOutput(void)
{
}


bool CFLTKOutput::Create(int iPosX, int iPosY, int iWidth, int iHeight, const char* pcTitle)
{
	if (m_bIsOK)
		return true;

	int iMenuHeight = 0;

	size(iWidth, iHeight);
	
	if (iPosX >= 0 && iPosY >= 0)
		position(iPosX, iPosY);


	begin();

	InitMenu();
	if (m_vecMenuItem.size() > 1)
	{
		iMenuHeight = 30;
		m_pMenuBar = new Fl_Menu_Bar(0, 0, iWidth, iMenuHeight);
		m_pMenuBar->copy(&m_vecMenuItem[0], this);
		m_bHasMenu = true;
	}

	m_pTextBuf = new Fl_Text_Buffer;

	m_pWinOutput = new Fl_Text_Editor(0, iMenuHeight, iWidth, iHeight - iMenuHeight);
	m_pWinOutput->buffer(m_pTextBuf);
	m_pWinOutput->box(FL_NO_BOX);
	m_pWinOutput->resizable(m_pWinOutput);
	m_pWinOutput->textfont(FL_COURIER);
	m_pWinOutput->end();

	resizable(m_pWinOutput);
	callback((Fl_Callback *) CFLTKOutput::CB_Quit, this);

	end();


	if (pcTitle)
		label(pcTitle);

	Show();

	m_bIsOK = true;
	return true;
}


void CFLTKOutput::Show()
{
	show();
}


bool CFLTKOutput::SetText(const char* pcText)
{
	if (pcText)
	{
		m_pTextBuf->text(pcText);
		return true;
	}

	return false;
}


/////////////////////////////////////////////////////////////////////
/// Init Menu

void CFLTKOutput::InitMenu()
{
	Fl_Menu_Item pMenuItems[] = 
	{
		{ "&Edit", 0, 0, 0, FL_SUBMENU },
		{ "&Copy",       FL_CTRL + 'c', (Fl_Callback *) CB_Copy },
		{ 0 },

		{ 0 }
	};

	m_vecMenuItem.clear();
	m_vecMenuItem.resize(4);

	for (int i = 0; i < 4; i++)
	{
		m_vecMenuItem[i] = pMenuItems[i];
	}
}

/////////////////////////////////////////////////////////////////////
/// Standard Implementations of virtual functions

void CFLTKOutput::Copy()
{
	Fl_Text_Editor::kf_copy(0, m_pWinOutput);
}

void CFLTKOutput::Quit()
{
	exit(0);
}

/////////////////////////////////////////////////////////////////////
/// Callbacks

void CFLTKOutput::CB_Copy(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKOutput *) pData)->Copy();
}


void CFLTKOutput::CB_Quit(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKOutput *) pData)->Quit();
}

