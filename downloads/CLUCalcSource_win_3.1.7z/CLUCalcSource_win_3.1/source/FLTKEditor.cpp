/// LICENSE START
////////////////////////////////////////////////////////////////////////////////////
//
// This file is part of the CLUCalc program.
// CLUCalc is an interactive Clifford calculator with OpenGL visualiations.
//
// 
// Copyright (C) 2002-2004  Christian B.U. Perwass
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
// The GNU Library General Public License can be found in the file
// license.txt distributed with this library.
//
// Please send all queries and comments to
//
// email: help@clucalc.info
// mail: Institut fuer Informatik, Olshausenstr. 40, 24098 Kiel, Germany.
//
////////////////////////////////////////////////////////////////////////////////////
/// LICENSE END



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#include "FLTKEditor.h"


CFLTKEditor::CFLTKEditor() : Fl_Double_Window(100, 100)
{
	m_pReplaceDlg = 0;
    m_pReplaceFind = 0;
    m_pReplaceWith = 0;
    m_pReplaceAll = 0;
    m_pReplaceNext = 0;
    m_pReplaceCancel = 0;
	m_pEditor = 0;
	m_pTextBuf = 0;

	m_bChanged = false;
	m_bLoading = false;
	m_bIsOK = false;

	m_sPath = "./";

	m_sFileChooserLoadTitle = "Load File";
	m_sFileChooserSaveTitle = "Save File";
	m_sFileChooserPattern = "All Files (*)";
}


CFLTKEditor::CFLTKEditor(int iPosX, int iPosY, int iWidth, int iHeight, const char* pcFilename)
		: Fl_Double_Window(iWidth, iHeight)
{
	m_pReplaceDlg = 0;
    m_pReplaceFind = 0;
    m_pReplaceWith = 0;
    m_pReplaceAll = 0;
    m_pReplaceNext = 0;
    m_pReplaceCancel = 0;
	m_pEditor = 0;

	m_bChanged = false;
	m_bLoading = false;
	m_bIsOK = false;

	m_sFileChooserLoadTitle = "Load File";
	m_sFileChooserSaveTitle = "Save File";
	m_sFileChooserPattern = "All Files (*)";

	Create(iPosX, iPosY, iWidth, iHeight, pcFilename);
	Show();
}



CFLTKEditor::~CFLTKEditor(void)
{
	if (m_pReplaceDlg)
		delete m_pReplaceDlg;
}


bool CFLTKEditor::Create(int iPosX, int iPosY, int iWidth, int iHeight, const char* pcFilename)
{
	if (m_bIsOK)
		return true;

	size(iWidth, iHeight);
	
	if (iPosX >= 0 && iPosY >= 0)
		position(iPosX, iPosY);

	m_pReplaceDlg = new Fl_Window(300, 105, "Replace");
	m_pReplaceDlg->begin();

	m_pReplaceFind = new Fl_Input(80, 10, 210, 25, "Find:");
	m_pReplaceFind->align(FL_ALIGN_LEFT);

	m_pReplaceWith = new Fl_Input(80, 40, 210, 25, "Replace:");
	m_pReplaceWith->align(FL_ALIGN_LEFT);

	m_pReplaceAll = new Fl_Button(10, 70, 90, 25, "Replace All");
	m_pReplaceAll->callback((Fl_Callback *) CB_ReplaceAll, this);

	m_pReplaceNext = new Fl_Return_Button(105, 70, 120, 25, "Replace Next");
	m_pReplaceNext->callback((Fl_Callback *) CB_Replace2, this);

	m_pReplaceCancel = new Fl_Button(230, 70, 60, 25, "Cancel");
	m_pReplaceCancel->callback((Fl_Callback *) CB_ReplaceCan, this);

	m_pReplaceDlg->end();
	m_pReplaceDlg->set_non_modal();

	m_pTextBuf = new Fl_Text_Buffer;
	m_pTextBuf->tab_distance(4);

	m_pStyleBuf = new Fl_Text_Buffer;

	begin();

	InitMenu();
	m_pMenuBar = new Fl_Menu_Bar(0, 0, iWidth, 30);
	m_pMenuBar->copy(&m_vecMenuItem[0], this);

	m_pEditor = new Fl_Text_Editor(0, 30, iWidth, iHeight-30);
	m_pEditor->buffer(m_pTextBuf);

	InitStyleTable();
	m_pEditor->highlight_data(m_pStyleBuf, &m_vecStyleTable[0],
								m_vecStyleTable.size(), 'A', 
								CB_StyleUnfinished, this);

	m_pEditor->textfont(FL_COURIER);

	end();

	resizable(m_pEditor);
	callback((Fl_Callback *) CFLTKEditor::CB_Quit, this);

	m_pTextBuf->add_modify_callback(CFLTKEditor::CB_StyleUpdate, this);
	m_pTextBuf->add_modify_callback(CFLTKEditor::CB_Changed, this);
	m_pTextBuf->call_modify_callbacks();

	if (pcFilename)
	{
		LoadFile(pcFilename);
	}
	else
	{
		SetTitle();
	}

	m_bIsOK = true;
	return true;
}


void CFLTKEditor::Show()
{
	show();
}

/////////////////////////////////////////////////////////////////////
/// Init Menu

void CFLTKEditor::InitMenu()
{
	Fl_Menu_Item pMenuItems[] = 
	{
		{ "&File",              0, 0, 0, FL_SUBMENU },
		{ "&New File",        FL_CTRL + 'n', (Fl_Callback *) CB_New },
		{ "&Open File...",    FL_CTRL + 'o', (Fl_Callback *) CB_Load },
		{ "&Insert File...",  FL_CTRL + 'i', (Fl_Callback *) CB_Insert, 0, FL_MENU_DIVIDER },
		{ "&Save File",       FL_CTRL + 's', (Fl_Callback *) CB_Save },
		{ "Save File &As...", FL_CTRL + FL_SHIFT + 's', (Fl_Callback *) CB_SaveAs, 0, FL_MENU_DIVIDER },
		{ "E&xit", FL_CTRL + 'q', (Fl_Callback *) CB_Quit, 0 },
		{ 0 },

		{ "&Edit", 0, 0, 0, FL_SUBMENU },
		{ "Cu&t",        FL_CTRL + 'x', (Fl_Callback *) CB_Cut },
		{ "&Copy",       FL_CTRL + 'c', (Fl_Callback *) CB_Copy },
		{ "&Paste",      FL_CTRL + 'v', (Fl_Callback *) CB_Paste },
		{ "&Delete",     0, (Fl_Callback *) CB_Delete },
		{ 0 },

		{ "&Search", 0, 0, 0, FL_SUBMENU },
		{ "&Find...",       FL_CTRL + 'f', (Fl_Callback *) CB_Find },
		{ "F&ind Again",    FL_CTRL + 'g', (Fl_Callback *) CB_Find2 },
		{ "&Replace...",    FL_CTRL + 'r', (Fl_Callback *) CB_Replace },
		{ "Re&place Again", FL_CTRL + 't', (Fl_Callback *) CB_Replace2 },
		{ 0 },

		{ 0 }
	};

	m_vecMenuItem.clear();
	m_vecMenuItem.resize(21);

	for (int i = 0; i < 21; i++)
	{
		m_vecMenuItem[i] = pMenuItems[i];
	}
}

void CFLTKEditor::InitStyleTable()
{
	Fl_Text_Display::Style_Table_Entry pStyleTable[] = 
	{	// Style table
		{ FL_BLACK,      FL_COURIER,        14 } // A - Plain
	};

	m_vecStyleTable.clear();
	m_vecStyleTable.resize(1);
	m_vecStyleTable[0] = pStyleTable[0];

}



/////////////////////////////////////////////////////////////////////
/// Helper Functions


/////////////////////////////////////////////////////////////////////
/// Set Name And Path

void CFLTKEditor::SetNameAndPath()
{
	char *pcSlash, pcPath[500];

	strncpy(pcPath, m_sFilename.c_str(), 499);
	pcSlash = (char *) strrchr(pcPath, '/');

#ifdef WIN32
	if (pcSlash == 0) 
		pcSlash = strrchr(pcPath, '\\');
#endif

	// Get Name of script without extension
	char *pcDot;
	pcDot = (char *) strrchr(pcPath, '.');
	if (pcDot)
		pcDot[0] = 0;

	if (pcSlash != 0) 
	{
		m_sName = &pcSlash[1];

		// Get Path to script
		pcSlash[1] = 0;
		m_sPath = pcPath;
	}
	else 
	{
		m_sName = pcPath;
		m_sPath = "./";
	}
}

void CFLTKEditor::LoadFile(const char* pcFilename, int iPos)
{
	m_bLoading = true;

	bool bInsert = false;

	if (iPos >= 0)
		bInsert = true;

	m_bChanged = bInsert;

	int iR;
	if (!bInsert) 
	{
		m_sFilename = "";
		iR = m_pTextBuf->loadfile(pcFilename);
	}
	else 
	{
		iR = m_pTextBuf->insertfile(pcFilename, iPos);
	}

	if (iR)
	{
		fl_alert("Error reading from file \'%s\':\n%s.", pcFilename, strerror(errno));
	}
	else
	{
		if (!bInsert) 
			m_sFilename = pcFilename;
		
		SetNameAndPath();
	}

	m_bLoading = false;
	m_pTextBuf->call_modify_callbacks();

}


void CFLTKEditor::SaveFile(const char* pcFilename)
{
	if (m_pTextBuf->savefile(pcFilename))
	{
		fl_alert("Error writing to file \'%s\':\n%s.", pcFilename, strerror(errno));
	}
	else
	{
		m_sFilename = pcFilename;
		SetNameAndPath();
	}

	m_bChanged = false;
	m_pTextBuf->call_modify_callbacks();
}


bool CFLTKEditor::CheckSave()
{
	if (!m_bChanged) 
		return true;

	int iR = fl_choice("The current file has not been saved.\n"
		"Would you like to save it now?",
		"Cancel", "Save", "Discard");

	if (iR == 1) 
	{
		Save(); // Save the file...
		return !m_bChanged;
	}

	return (iR == 2) ? true : false;
}


bool CFLTKEditor::SetTitle()
{
	m_sTitle = "CLUCalc v" CLUCALC_VERSION " by C. Perwass - ";

	if (m_sFilename[0] == 0) 
	{
		m_sTitle += "Untitled";
	}
	else 
	{
		char *pcSlash, *pcFilename;

		pcFilename = (char *) m_sFilename.c_str();
		pcSlash = (char *) strrchr(pcFilename, '/');

#ifdef WIN32
		if (pcSlash == 0) 
			pcSlash = strrchr(pcFilename, '\\');
#endif

		if (pcSlash != 0) 
		{
			m_sTitle += &pcSlash[1];
		}
		else 
		{
			m_sTitle += pcFilename;
		}
	}

	if (m_bChanged) 
	{
		m_sTitle += " (modified)";
	}

	label(m_sTitle.c_str());

	return true;
}


/////////////////////////////////////////////////////////////////////
/// Standard Implementations of virtual functions

void CFLTKEditor::Copy()
{
	Fl_Text_Editor::kf_copy(0, m_pEditor);
}

void CFLTKEditor::Cut()
{
	Fl_Text_Editor::kf_cut(0, m_pEditor);
}

void CFLTKEditor::Paste()
{
	Fl_Text_Editor::kf_paste(0, m_pEditor);
}

void CFLTKEditor::Delete()
{
	m_pTextBuf->remove_selection();
}

void CFLTKEditor::Find()
{
	char *pcVal;

	pcVal = (char *) fl_input("Search String:", m_pcSearchString);

	if (pcVal != NULL) 
	{
		// User entered a string - go find it!
		strcpy(m_pcSearchString, pcVal);
		Find2();
	}
}

void CFLTKEditor::Find2()
{
	if (m_pcSearchString[0] == 0) 
	{
		// Search string is blank; get a new one...
		Find();
		return;
	}

	int iPos = m_pEditor->insert_position();
	int iFound = m_pTextBuf->search_forward(iPos, m_pcSearchString, &iPos);

	if (iFound) 
	{
		// Found a match; select and update the position...
		m_pTextBuf->select(iPos, iPos + (int) strlen(m_pcSearchString));
		m_pEditor->insert_position(iPos + (int) strlen(m_pcSearchString));
		m_pEditor->show_insert_position();
	}
	else 
	{
		fl_alert("No occurrences of \'%s\' found!", m_pcSearchString);
	}
}


void CFLTKEditor::Replace()
{
	m_pReplaceDlg->show();
}

void CFLTKEditor::Replace2()
{
	char *pcFind = (char *) m_pReplaceFind->value();
	char *pcReplace = (char *) m_pReplaceWith->value();

	if (pcFind[0] == 0) 
	{
		// Search string is blank; get a new one...
		m_pReplaceDlg->show();
		return;
	}

	m_pReplaceDlg->hide();

	int iPos = m_pEditor->insert_position();
	int iFound = m_pTextBuf->search_forward(iPos, pcFind, &iPos);

	if (iFound) 
	{
		// Found a match; update the position and replace text...
		m_pTextBuf->select(iPos, iPos + (int) strlen(pcFind));
		m_pTextBuf->remove_selection();
		m_pTextBuf->insert(iPos, pcReplace);
		m_pTextBuf->select(iPos, iPos + (int) strlen(pcReplace));
		m_pEditor->insert_position(iPos + (int) strlen(pcReplace));
		m_pEditor->show_insert_position();
	}
	else 
	{
		fl_alert("No occurrences of \'%s\' found!", pcFind);
	}
}

void CFLTKEditor::ReplaceAll()
{
	char *pcFind = (char *) m_pReplaceFind->value();
	char *pcReplace = (char *) m_pReplaceWith->value();

	if (pcFind[0] == 0) 
	{
		// Search string is blank; get a new one...
		m_pReplaceDlg->show();
		return;
	}

	m_pReplaceDlg->hide();

	m_pEditor->insert_position(0);

	// Loop through the whole string
	int iFound;
	int iTimes = 0;

	do 
	{
		int iPos = m_pEditor->insert_position();
		iFound = m_pTextBuf->search_forward(iPos, pcFind, &iPos);

		if (iFound) 
		{
			// Found a match; update the position and pcReplace text...
			m_pTextBuf->select(iPos, iPos + (int) strlen(pcFind));
			m_pTextBuf->remove_selection();
			m_pTextBuf->insert(iPos, pcReplace);
			m_pEditor->insert_position(iPos + (int) strlen(pcReplace));
			m_pEditor->show_insert_position();
			iTimes++;
		}
	} while (iFound);

	if (iTimes) 
	{
		fl_message("Replaced %d occurrences.", iTimes);
	}
	else 
	{
		fl_alert("No occurrences of \'%s\' found!", pcFind);
	}
}


void CFLTKEditor::ReplaceCan()
{
	m_pReplaceDlg->hide();
}


void CFLTKEditor::New()
{
	if (!CheckSave())
		return;

	m_sFilename = "";
	m_sName = "Untitled";
	m_sPath = "./";
	m_pTextBuf->select(0, m_pTextBuf->length());
	m_pTextBuf->remove_selection();
	m_bChanged = false;
	m_pTextBuf->call_modify_callbacks();
}


void CFLTKEditor::Load()
{
	if (!CheckSave())
		return;

	char pcFilename[512];

	pcFilename[0] = 0;
	Fl_File_Chooser::sort = fl_casenumericsort;
	char *pcNewFile = fl_file_chooser(m_sFileChooserLoadTitle.c_str(), 
							m_sFileChooserPattern.c_str(), pcFilename);

	if (pcNewFile != NULL) 
		LoadFile(pcNewFile);
}

void CFLTKEditor::Insert()
{
	char pcFilename[512];
	Fl_File_Chooser::sort = fl_casenumericsort;
	char *pcNewFile = fl_file_chooser(m_sFileChooserLoadTitle.c_str(), 
							m_sFileChooserPattern.c_str(), pcFilename);

	if (pcNewFile != NULL) 
		LoadFile(pcNewFile, m_pEditor->insert_position());
}

void CFLTKEditor::Close()
{
	New();
}


void CFLTKEditor::Save()
{
	if (m_sFilename[0] == 0)
	{
		SaveAs();
		return;
	}

	SaveFile(m_sFilename.c_str());
}

void CFLTKEditor::SaveAs()
{
	char *pcNewFile;
	char pcFilename[512];

	pcFilename[0] = 0;
	Fl_File_Chooser::sort = fl_casenumericsort;
	pcNewFile = fl_file_chooser(m_sFileChooserSaveTitle.c_str(), 
		m_sFileChooserPattern.c_str(), pcFilename);

	if (pcNewFile != NULL) 
	{
		if (*fl_filename_ext(pcNewFile) == 0)
			strcat(pcNewFile, ".clu");

		SaveFile(pcNewFile);
	}
}

void CFLTKEditor::Quit()
{
	if (!CheckSave())
		return;

	exit(0);
}

void CFLTKEditor::Changed(int iVal, int nInserted, int nDeleted, 
						int iVal2, const char* pcVal)
{
  if ((nInserted || nDeleted) && !m_bLoading) 
	  m_bChanged = true;

  SetTitle();

  if (m_bLoading) 
	  m_pEditor->show_insert_position();
}


void CFLTKEditor::StyleUnfinished(int iVal)
{
	return;
}

void CFLTKEditor::StyleParse(const char *pcText, char *pcStyle, int iLength)
{
	return;
}

void CFLTKEditor::StyleUpdate(int iPos, int nInserted,	int nDeleted,
							  int nRestyled, const char *deletedText)
{
	int	iStart,			// Start of text
		iEnd;			// End of text

	char	cLast,			// Last style on line
		*pcStyle,		// Style data
		*pcText;		// Text data


	// If this is just a selection change, just unselect the style buffer...
	if (nInserted == 0 && nDeleted == 0) 
	{
		m_pStyleBuf->unselect();
		return;
	}

	// Track changes in the text buffer...
	if (nInserted > 0) 
	{
		// Insert characters into the style buffer...
		pcStyle = new char[nInserted + 1];
		memset(pcStyle, 'A', nInserted);
		pcStyle[nInserted] = '\0';

		m_pStyleBuf->replace(iPos, iPos + nDeleted /*nInserted*/, pcStyle);
		delete[] pcStyle;
	} 
	else 
	{
		// Just delete characters in the style buffer...
		m_pStyleBuf->remove(iPos, iPos + nDeleted);
	}

	// Select the area that was just updated to avoid unnecessary
	// callbacks...
	if (iPos > 0)
		iPos--;

	m_pStyleBuf->select(iPos, iPos + nInserted - nDeleted + 1);

	// Re-parse the changed region; we do this by parsing from the
	// beginning of the line of the changed region to the end of
	// the line of the changed region...  Then we check the last
	// style character and keep updating if we have a multi-line
	// comment character...
	iStart = m_pTextBuf->line_start(iPos);
	iEnd   = m_pTextBuf->line_end(iPos + nInserted + 1);
	pcText  = m_pTextBuf->text_range(iStart, iEnd);
	pcStyle = m_pStyleBuf->text_range(iStart, iEnd);
	cLast  = pcStyle[iEnd - iStart - 1];

	//  printf("iStart = %d, iEnd = %d, pcText = \"%s\", pcStyle = \"%s\"...\n",
	//         iStart, iEnd, pcText, pcStyle);

	m_bReparsing = false;
	m_bReparseAll = false;
	StyleParse(pcText, pcStyle, iEnd - iStart);

	//  printf("new pcStyle = \"%s\"...\n", pcStyle);

	m_pStyleBuf->replace(iStart, iEnd, pcStyle);
	m_pEditor->redisplay_range(iStart, iEnd);

	if (m_bReparseAll) //cLast != pcStyle[iEnd - iStart - 1] || pcStyle[iEnd - iStart - 1] == 'Z') 
	{
		// The cLast character on the line changed styles, so reparse the
		// remainder of the buffer...
		free(pcText);
		free(pcStyle);

		iStart = 0;
		iEnd   = m_pTextBuf->length();
		pcText  = m_pTextBuf->text_range(iStart, iEnd);
		pcStyle = m_pStyleBuf->text_range(iStart, iEnd);

		m_bReparsing = true;
		StyleParse(pcText, pcStyle, iEnd - iStart);

		m_pStyleBuf->replace(iStart, iEnd, pcStyle);
		m_pEditor->redisplay_range(iStart, iEnd);
	}

	free(pcText);
	free(pcStyle);
}


/////////////////////////////////////////////////////////////////////
/// Callbacks

void CFLTKEditor::CB_Copy(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->Copy();
}

void CFLTKEditor::CB_Cut(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->Cut();
}

void CFLTKEditor::CB_Delete(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->Delete();
}

void CFLTKEditor::CB_Paste(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->Paste();
}

void CFLTKEditor::CB_Find(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->Find();
}

void CFLTKEditor::CB_Find2(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->Find2();
}

void CFLTKEditor::CB_Replace(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->Replace();
}

void CFLTKEditor::CB_Replace2(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->Replace2();
}

void CFLTKEditor::CB_ReplaceAll(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->ReplaceAll();
}

void CFLTKEditor::CB_ReplaceCan(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->ReplaceCan();
}

void CFLTKEditor::CB_New(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->New();
}

void CFLTKEditor::CB_Load(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->Load();
}

void CFLTKEditor::CB_Insert(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->Insert();
}

void CFLTKEditor::CB_Close(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->Close();
}

void CFLTKEditor::CB_Save(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->Save();
}

void CFLTKEditor::CB_SaveAs(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->SaveAs();
}

void CFLTKEditor::CB_Quit(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->Quit();
}

/*
void CFLTKEditor::CB_View(Fl_Widget* pWidget, void *pData)
{
	if (pData)
		((CFLTKEditor *) pData)->View();
}
*/

void CFLTKEditor::CB_Changed(int iVal, int nInserted, int nDeleted, 
						int iVal2, const char* pcVal, void* pvVal)
{
	if (pvVal)
		((CFLTKEditor *) pvVal)->Changed(iVal, nInserted, nDeleted, iVal2, pcVal);
}


void CFLTKEditor::CB_StyleUnfinished(int iVal, void *pvVal)
{
	if (pvVal)
		((CFLTKEditor *) pvVal)->StyleUnfinished(iVal);
}

void CFLTKEditor::CB_StyleUpdate(int iPos, int nInserted,	int nDeleted,
								int nRestyled, const char *pcDeletedText,
								void *pvData)
{
	if (pvData)
		((CFLTKEditor *)pvData)->StyleUpdate(iPos, nInserted, nDeleted, nRestyled, pcDeletedText);
}

