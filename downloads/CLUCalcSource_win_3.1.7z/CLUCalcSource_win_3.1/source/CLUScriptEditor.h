/// LICENSE START
////////////////////////////////////////////////////////////////////////////////////
//
// This file is part of the CLUCalc program.
// CLUCalc is an interactive Clifford calculator with OpenGL visualiations.
//
// 
// Copyright (C) 2002-2004  Christian B.U. Perwass
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
// The GNU Library General Public License can be found in the file
// license.txt distributed with this library.
//
// Please send all queries and comments to
//
// email: help@clucalc.info
// mail: Institut fuer Informatik, Olshausenstr. 40, 24098 Kiel, Germany.
//
////////////////////////////////////////////////////////////////////////////////////
/// LICENSE END

#if !defined( _CLUSCRIPTEDITOR_H__INCLUDED_ )
#define _CLUSCRIPTEDITOR_H__INCLUDED_

#include "StdAfx.h"
#include "OGLWin.h"
#include "FLTKEditor.h"
#include "FLTKOutput.h"

#include <FL/Fl_Help_Dialog.H>

#include <map>

using namespace std;

class CCLUScriptEditor :
	public CFLTKEditor
{
public:
	CCLUScriptEditor(void);
	CCLUScriptEditor(int iPosX, int iPosY, int iWidth, int iHeight, 
					const char *pcFilename = 0, const char *pcExecPath = 0);
	~CCLUScriptEditor(void);

	bool Create(int iPosX, int iPosY, int iWidth, int iHeight, 
				const char *pcFilename = 0, const char *pcExecPath = 0);

	void SetExecPath(const char *pcExecPath)
	{ m_sExecPath = pcExecPath; }

	void SetOGLWin(COGLWin *poglWin)
	{ m_poglWin = poglWin; }

	void SetOutputWin(CFLTKOutput *pOutputWin)
	{ m_pOutputWin = pOutputWin; }

	void SetScript(const char* pcScript, bool bResetChangedFlag = false)
	{ 
		m_pTextBuf->text(pcScript);  	
		m_pTextBuf->call_modify_callbacks();

		if (bResetChangedFlag)
		{
			m_bChanged = false;
			SetTitle();
		}

		Parse();
	}

	void Parse(bool bResetEnv = false, bool bReparseLatex = false);

protected:
	void Help();
	void InitStyle();
	void InsertColor();

	void MenuShowEditorWin();
	void MenuShowOutputWin();
	void MenuShowVisWin();

protected:
	// Overloaded virtual functions
	void InitMenu();
	void New();
	void Load();
	void Insert();
	void Close();
	void SaveAs();

	void InitStyleTable();
	void StyleParse(const char *pcText, char *pcStyle, int iLength);

protected:
	static void CB_InsertColor(Fl_Widget *pWidget, void *pvData);
	static void CB_Parse(Fl_Widget *pWidget, void *pvData);
	static void CB_ParseForce(Fl_Widget *pWidget, void *pvData);
	static void CB_Help(Fl_Widget *pWidget, void *pvData);

	static void CB_ShowEditorWin(Fl_Widget *pWidget, void *pvData);
	static void CB_ShowOutputWin(Fl_Widget *pWidget, void *pvData);
	static void CB_ShowVisWin(Fl_Widget *pWidget, void *pvData);

protected:
	COGLWin *m_poglWin;
	CFLTKOutput *m_pOutputWin;

	Fl_Help_Dialog *m_pHelpDialog;

	string m_sAllowedChars;
	string m_sSymbolChars;
	string m_sStdSingleCharOps;
	string m_sSpcSingleCharOps;
	string m_sExecPath;
	map<string, char> m_mapHighlight;
	map<string, char> m_mapSymbol;
};


#endif
