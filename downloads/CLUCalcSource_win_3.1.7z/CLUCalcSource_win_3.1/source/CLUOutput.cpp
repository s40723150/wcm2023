/// LICENSE START
////////////////////////////////////////////////////////////////////////////////////
//
// This file is part of the CLUCalc program.
// CLUCalc is an interactive Clifford calculator with OpenGL visualiations.
//
// 
// Copyright (C) 2002-2004  Christian B.U. Perwass
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
// The GNU Library General Public License can be found in the file
// license.txt distributed with this library.
//
// Please send all queries and comments to
//
// email: help@clucalc.info
// mail: Institut fuer Informatik, Olshausenstr. 40, 24098 Kiel, Germany.
//
////////////////////////////////////////////////////////////////////////////////////
/// LICENSE END


#include "StdAfx.h"
#include "CLUOutput.h"


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>



CCLUOutput::CCLUOutput() : CFLTKOutput()
{
	m_poglWin = 0;
	m_pEditor = 0;
}


CCLUOutput::CCLUOutput(int iPosX, int iPosY, int iWidth, int iHeight, const char* pcTitle)
{
	m_poglWin = 0;
	m_pEditor = 0;

	Create(iPosX, iPosY, iWidth, iHeight, pcTitle);
}



CCLUOutput::~CCLUOutput(void)
{
}



/////////////////////////////////////////////////////////////////////
/// Init Menu

void CCLUOutput::InitMenu()
{
	CFLTKOutput::InitMenu();

	Fl_Menu_Item pMenuItems[] = 
	{
		{ "&Window",              0, 0, 0, FL_SUBMENU },
		{ "&Editor", FL_CTRL + FL_SHIFT + 'e', (Fl_Callback *) CB_ShowEditorWin },
		{ "&Output", FL_CTRL + FL_SHIFT + 'o', (Fl_Callback *) CB_ShowOutputWin },
		{ "&Visualization", FL_CTRL + FL_SHIFT + 'v', (Fl_Callback *) CB_ShowVisWin },
		{ 0 },

		{ 0 }
	};

	int iCount = m_vecMenuItem.size();
	m_vecMenuItem.resize(iCount + 5);

	for (int i = 0; i < 6; i++)
	{
		m_vecMenuItem[iCount + i - 1] = pMenuItems[i];
	}
}



//////////////////////////////////////////////////////////////////////
/// Window Menu Callbacks

void CCLUOutput::MenuShowEditorWin()
{
	if (m_pEditor)
		m_pEditor->show();
}

void CCLUOutput::MenuShowOutputWin()
{
	Show();
}

void CCLUOutput::MenuShowVisWin()
{
	if (m_poglWin)
		m_poglWin->ShowWindow();
}



void CCLUOutput::CB_ShowEditorWin(Fl_Widget *pWidget, void *pvData)
{
	if (pvData)
		((CCLUOutput *) pvData)->MenuShowEditorWin();
}

void CCLUOutput::CB_ShowOutputWin(Fl_Widget *pWidget, void *pvData)
{
	if (pvData)
		((CCLUOutput *) pvData)->MenuShowOutputWin();
}

void CCLUOutput::CB_ShowVisWin(Fl_Widget *pWidget, void *pvData)
{
	if (pvData)
		((CCLUOutput *) pvData)->MenuShowVisWin();
}



